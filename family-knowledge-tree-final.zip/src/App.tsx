import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { FamilyGraph } from './components/FamilyGraph';
import { ProfilePanel } from './components/ProfilePanel';
import { PersonForm } from './components/PersonForm';
import { RelationshipForm } from './components/RelationshipForm';
import { NoteForm } from './components/NoteForm';
import { Person, Relationship, Note } from './types';
import { api } from './services/api';
import { Loader2, Bell, Layout, Settings, HelpCircle, User } from 'lucide-react';
import { ReactFlowProvider } from '@xyflow/react';

const Header = () => (
  <header className="h-16 border-b border-zinc-200 bg-white flex items-center justify-between px-6 shrink-0 z-10">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 bg-zinc-900 rounded flex items-center justify-center text-white font-bold text-xl">
        F
      </div>
      <h1 className="text-lg font-bold text-zinc-900 tracking-tight">Family Knowledge Tree</h1>
    </div>
    <div className="flex items-center gap-5 text-zinc-400">
      <button className="hover:text-zinc-600 transition-colors" title="Notifications"><Bell size={20} /></button>
      <button className="hover:text-zinc-600 transition-colors" title="Settings"><Settings size={20} /></button>
      <div className="h-6 w-px bg-zinc-200 mx-1" />
      <button className="hover:text-zinc-600 transition-colors" title="Help"><HelpCircle size={20} /></button>
      <div className="w-8 h-8 rounded-full bg-zinc-100 border border-zinc-200 flex items-center justify-center overflow-hidden">
        <img src="https://picsum.photos/seed/user/100/100" alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
      </div>
    </div>
  </header>
);

const ConfirmModal = ({ 
  title, 
  message, 
  onConfirm, 
  onCancel 
}: { 
  title: string; 
  message: string; 
  onConfirm: () => void; 
  onCancel: () => void; 
}) => (
  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
    <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in duration-200">
      <div className="p-6 space-y-4">
        <h3 className="text-xl font-bold text-zinc-900">{title}</h3>
        <p className="text-zinc-600 leading-relaxed">{message}</p>
      </div>
      <div className="p-4 bg-zinc-50 flex items-center justify-end gap-3">
        <button 
          onClick={onCancel}
          className="px-4 py-2 text-sm font-bold text-zinc-600 hover:text-zinc-900 transition-colors"
        >
          Cancel
        </button>
        <button 
          onClick={onConfirm}
          className="px-6 py-2 bg-red-500 text-white rounded-lg shadow-lg shadow-red-500/20 hover:bg-red-600 transition-all text-sm font-bold"
        >
          Confirm Delete
        </button>
      </div>
    </div>
  </div>
);

export default function App() {
  return (
    <ReactFlowProvider>
      <AppContent />
    </ReactFlowProvider>
  );
}

function AppContent() {
  const [persons, setPersons] = useState<Person[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [allNotes, setAllNotes] = useState<Note[]>([]);
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Modals
  const [showPersonForm, setShowPersonForm] = useState(false);
  const [showRelationshipForm, setShowRelationshipForm] = useState(false);
  const [showNoteForm, setShowNoteForm] = useState(false);
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [confirmConfig, setConfirmConfig] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const fetchData = useCallback(async () => {
    try {
      console.log('Fetching data...');
      const [p, r, n] = await Promise.all([
        api.getPersons(),
        api.getRelationships(),
        api.getAllNotes()
      ]);
      console.log('Fetched persons:', p.length);
      console.log('Fetched relationships:', r.length);
      console.log('Fetched notes:', n.length);
      setPersons(p);
      setRelationships(r);
      setAllNotes(n);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAddPerson = async (person: Person) => {
    if (editingPerson) {
      await api.updatePerson(person.id, person);
    } else {
      await api.createPerson(person);
    }
    await fetchData();
    setShowPersonForm(false);
    setEditingPerson(null);
  };

  const handleAddRelationship = async (rel: Relationship) => {
    try {
      // 1. Create the primary relationship
      await api.createRelationship(rel);

      // 2. Auto-relations logic
      const autoRels: Partial<Relationship>[] = [];

      const getChildren = (parentId: string) => {
        const directChildren = relationships.filter(r => r.person1_id === parentId && r.type === 'PARENT_OF').map(r => r.person2_id);
        const childOfRels = relationships.filter(r => r.person2_id === parentId && r.type === 'CHILD_OF').map(r => r.person1_id);
        return Array.from(new Set([...directChildren, ...childOfRels]));
      };

      const getSiblings = (personId: string) => {
        const siblingRels = relationships.filter(r => r.type === 'SIBLING_OF' && (r.person1_id === personId || r.person2_id === personId));
        return siblingRels.map(r => r.person1_id === personId ? r.person2_id : r.person1_id);
      };

      const getSpouse = (personId: string) => {
        const spouseRel = relationships.find(r => r.type === 'SPOUSE_OF' && (r.person1_id === personId || r.person2_id === personId));
        return spouseRel ? (spouseRel.person1_id === personId ? spouseRel.person2_id : spouseRel.person1_id) : null;
      };

      if (rel.type === 'SPOUSE_OF') {
        // If X is spouse of Y
        // 1. Children of X -> Y is PARENT_OF them
        const xChildren = getChildren(rel.person1_id);
        xChildren.forEach(childId => {
          const alreadyExists = relationships.some(r => 
            r.person1_id === rel.person2_id && r.person2_id === childId && (r.type === 'PARENT_OF' || r.type === 'CHILD_OF')
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person2_id, person2_id: childId, type: 'PARENT_OF' });
          }
        });

        // 2. Children of Y -> X is PARENT_OF them
        const yChildren = getChildren(rel.person2_id);
        yChildren.forEach(childId => {
          const alreadyExists = relationships.some(r => 
            r.person1_id === rel.person1_id && r.person2_id === childId && (r.type === 'PARENT_OF' || r.type === 'CHILD_OF')
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person1_id, person2_id: childId, type: 'PARENT_OF' });
          }
        });

        // 3. Siblings of X -> Y is IN_LAW_OF them
        const xSiblings = getSiblings(rel.person1_id);
        xSiblings.forEach(siblingId => {
          const alreadyExists = relationships.some(r => 
            r.type === 'IN_LAW_OF' && ((r.person1_id === rel.person2_id && r.person2_id === siblingId) || (r.person1_id === siblingId && r.person2_id === rel.person2_id))
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person2_id, person2_id: siblingId, type: 'IN_LAW_OF' });
          }
        });

        // 4. Siblings of Y -> X is IN_LAW_OF them
        const ySiblings = getSiblings(rel.person2_id);
        ySiblings.forEach(siblingId => {
          const alreadyExists = relationships.some(r => 
            r.type === 'IN_LAW_OF' && ((r.person1_id === rel.person1_id && r.person2_id === siblingId) || (r.person1_id === siblingId && r.person2_id === rel.person1_id))
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person1_id, person2_id: siblingId, type: 'IN_LAW_OF' });
          }
        });
      } else if (rel.type === 'PARENT_OF' || rel.type === 'CHILD_OF') {
        const parentId = rel.type === 'PARENT_OF' ? rel.person1_id : rel.person2_id;
        const childId = rel.type === 'PARENT_OF' ? rel.person2_id : rel.person1_id;

        // 1. Spouse of Parent -> they are also PARENT_OF Child
        const spouseId = getSpouse(parentId);
        if (spouseId) {
          const alreadyExists = relationships.some(r => 
            ((r.person1_id === spouseId && r.person2_id === childId) || (r.person1_id === childId && r.person2_id === spouseId)) && 
            (r.type === 'PARENT_OF' || r.type === 'CHILD_OF')
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: spouseId, person2_id: childId, type: 'PARENT_OF' });
          }
        }

        // 2. Siblings of Parent -> they are UNCLE_AUNT_OF Child
        const parentSiblings = getSiblings(parentId);
        parentSiblings.forEach(siblingId => {
          const alreadyExists = relationships.some(r => 
            r.person1_id === siblingId && r.person2_id === childId && r.type === 'UNCLE_AUNT_OF'
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: siblingId, person2_id: childId, type: 'UNCLE_AUNT_OF' });
          }
        });
      } else if (rel.type === 'SIBLING_OF') {
        // If X is sibling of Y
        // 1. Children of X -> Y is UNCLE_AUNT_OF them
        const xChildren = getChildren(rel.person1_id);
        xChildren.forEach(childId => {
          const alreadyExists = relationships.some(r => 
            r.person1_id === rel.person2_id && r.person2_id === childId && r.type === 'UNCLE_AUNT_OF'
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person2_id, person2_id: childId, type: 'UNCLE_AUNT_OF' });
          }
        });

        // 2. Children of Y -> X is UNCLE_AUNT_OF them
        const yChildren = getChildren(rel.person2_id);
        yChildren.forEach(childId => {
          const alreadyExists = relationships.some(r => 
            r.person1_id === rel.person1_id && r.person2_id === childId && r.type === 'UNCLE_AUNT_OF'
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person1_id, person2_id: childId, type: 'UNCLE_AUNT_OF' });
          }
        });

        // 3. Spouse of X -> Y is IN_LAW_OF them
        const xSpouseId = getSpouse(rel.person1_id);
        if (xSpouseId) {
          const alreadyExists = relationships.some(r => 
            r.type === 'IN_LAW_OF' && ((r.person1_id === rel.person2_id && r.person2_id === xSpouseId) || (r.person1_id === xSpouseId && r.person2_id === rel.person2_id))
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person2_id, person2_id: xSpouseId, type: 'IN_LAW_OF' });
          }
        }

        // 4. Spouse of Y -> X is IN_LAW_OF them
        const ySpouseId = getSpouse(rel.person2_id);
        if (ySpouseId) {
          const alreadyExists = relationships.some(r => 
            r.type === 'IN_LAW_OF' && ((r.person1_id === rel.person1_id && r.person2_id === ySpouseId) || (r.person1_id === ySpouseId && r.person2_id === rel.person1_id))
          );
          if (!alreadyExists) {
            autoRels.push({ person1_id: rel.person1_id, person2_id: ySpouseId, type: 'IN_LAW_OF' });
          }
        }
      }

      // Create all auto-relations
      for (const autoRel of autoRels) {
        await api.createRelationship(autoRel as Relationship);
      }

      await fetchData();
      setShowRelationshipForm(false);
    } catch (error) {
      console.error('Failed to add relationship:', error);
    }
  };

  const handleAddNote = async (note: Partial<Note>) => {
    if (selectedPersonId) {
      await api.createNote(note as Note);
      await fetchData();
      setShowNoteForm(false);
    }
  };

  const handleDeletePerson = (id: string) => {
    setConfirmConfig({
      title: 'Delete Family Member',
      message: 'Are you sure you want to delete this family member? This will also remove all their relationships and conversation logs.',
      onConfirm: async () => {
        try {
          await api.deletePerson(id);
          await fetchData();
          setSelectedPersonId(null);
          setConfirmConfig(null);
        } catch (error) {
          console.error('Failed to delete person:', error);
        }
      }
    });
  };

  const handleDeleteRelationship = (id: string) => {
    setConfirmConfig({
      title: 'Delete Relationship',
      message: 'Are you sure you want to delete this relationship?',
      onConfirm: async () => {
        try {
          await api.deleteRelationship(id);
          await fetchData();
          setConfirmConfig(null);
        } catch (error) {
          console.error('Failed to delete relationship:', error);
        }
      }
    });
  };

  const handleDeleteNote = (id: string) => {
    setConfirmConfig({
      title: 'Delete Conversation Log',
      message: 'Are you sure you want to delete this conversation log entry?',
      onConfirm: async () => {
        try {
          await api.deleteNote(id);
          await fetchData();
          setConfirmConfig(null);
        } catch (error) {
          console.error('Failed to delete note:', error);
        }
      }
    });
  };

  const selectedPerson = persons.find(p => p.id === selectedPersonId) || null;

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-zinc-50 gap-4">
        <Loader2 className="animate-spin text-zinc-900" size={40} />
        <p className="text-zinc-500 font-medium animate-pulse">Loading Family Tree...</p>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-white overflow-hidden font-sans text-zinc-900">
      <Header />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar 
          persons={persons} 
          relationships={relationships}
          selectedPersonId={selectedPersonId}
          onSelectPerson={setSelectedPersonId}
          onAddPerson={() => {
            setEditingPerson(null);
            setShowPersonForm(true);
          }}
          onDeleteRelationship={handleDeleteRelationship}
        />

        <main className="flex-1 flex flex-col relative">
          <FamilyGraph 
            persons={persons} 
            relationships={relationships}
            allNotes={allNotes}
            selectedPersonId={selectedPersonId}
            onSelectPerson={setSelectedPersonId}
            onAddRelationship={() => setShowRelationshipForm(true)}
          />
        </main>

        {selectedPerson && (
          <ProfilePanel 
            person={selectedPerson}
            allPersons={persons}
            allRelationships={relationships}
            onClose={() => setSelectedPersonId(null)}
            onEdit={(p) => {
              setEditingPerson(p);
              setShowPersonForm(true);
            }}
            onDelete={handleDeletePerson}
            onDeleteNote={handleDeleteNote}
            onRefresh={fetchData}
            onAddNote={() => setShowNoteForm(true)}
          />
        )}
      </div>

      {confirmConfig && (
        <ConfirmModal 
          title={confirmConfig.title}
          message={confirmConfig.message}
          onConfirm={confirmConfig.onConfirm}
          onCancel={() => setConfirmConfig(null)}
        />
      )}

      {showNoteForm && selectedPersonId && (
        <NoteForm 
          personId={selectedPersonId}
          onSave={handleAddNote}
          onClose={() => setShowNoteForm(false)}
        />
      )}

      {showPersonForm && (
        <PersonForm 
          person={editingPerson}
          onSave={handleAddPerson}
          onClose={() => {
            setShowPersonForm(false);
            setEditingPerson(null);
          }}
        />
      )}

      {showRelationshipForm && (
        <RelationshipForm 
          persons={persons}
          onSave={handleAddRelationship}
          onClose={() => setShowRelationshipForm(false)}
        />
      )}
    </div>
  );
}
