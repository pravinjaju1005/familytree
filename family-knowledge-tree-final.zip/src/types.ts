export type Gender = 'Male' | 'Female' | 'Other' | 'Unknown';

export interface Person {
  id: string;
  full_name: string;
  nickname?: string;
  gender: Gender;
  birth_date?: string;
  birth_time?: string;
  birth_place?: string;
  current_location?: string;
  profession?: string;
  current_company?: string;
  anniversary?: string;
  education?: string;
  bio?: string;
  photo_url?: string;
  custom_fields?: string; // JSON string of Record<string, string>
  created_at?: string;
  updated_at?: string;
}

export type RelationshipType = 
  | 'PARENT_OF' 
  | 'SPOUSE_OF' 
  | 'SIBLING_OF' 
  | 'CHILD_OF' 
  | 'UNCLE_AUNT_OF'
  | 'IN_LAW_OF'
  | 'OTHER';

export interface Relationship {
  id: string;
  person1_id: string;
  person2_id: string;
  type: RelationshipType;
  metadata?: string;
  created_at?: string;
}

export interface Note {
  id: string;
  person_id: string;
  date: string;
  topic: string;
  content: string;
  follow_up_reminder?: string;
  created_at?: string;
}
