import { Person, Relationship, Note } from '../types';

const API_BASE = '/api';

export const api = {
  // Persons
  async getPersons(): Promise<Person[]> {
    const res = await fetch(`${API_BASE}/persons`);
    return res.json();
  },
  async createPerson(person: Person): Promise<{ id: string }> {
    const res = await fetch(`${API_BASE}/persons`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(person),
    });
    return res.json();
  },
  async updatePerson(id: string, person: Partial<Person>): Promise<void> {
    await fetch(`${API_BASE}/persons/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(person),
    });
  },
  async deletePerson(id: string): Promise<void> {
    await fetch(`${API_BASE}/persons/${id}`, { method: 'DELETE' });
  },

  // Relationships
  async getRelationships(): Promise<Relationship[]> {
    const res = await fetch(`${API_BASE}/relationships`);
    return res.json();
  },
  async createRelationship(rel: Relationship): Promise<{ id: string }> {
    const res = await fetch(`${API_BASE}/relationships`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rel),
    });
    return res.json();
  },
  async deleteRelationship(id: string): Promise<void> {
    await fetch(`${API_BASE}/relationships/${id}`, { method: 'DELETE' });
  },

  // Notes
  async getAllNotes(): Promise<Note[]> {
    const res = await fetch(`${API_BASE}/notes`);
    return res.json();
  },
  async getNotes(personId: string): Promise<Note[]> {
    const res = await fetch(`${API_BASE}/persons/${personId}/notes`);
    return res.json();
  },
  async createNote(note: Note): Promise<{ id: string }> {
    const res = await fetch(`${API_BASE}/notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(note),
    });
    return res.json();
  },
  async deleteNote(id: string): Promise<void> {
    await fetch(`${API_BASE}/notes/${id}`, { method: 'DELETE' });
  },
};
