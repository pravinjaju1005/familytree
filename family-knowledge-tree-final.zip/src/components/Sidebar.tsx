import React, { useState } from 'react';
import { Search, UserPlus, ChevronDown, User, Plus, Users, Trash2, Briefcase, MapPin, Info } from 'lucide-react';
import { Person, Relationship } from '../types';
import { RelationshipFinder } from './RelationshipFinder';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SidebarProps {
  persons: Person[];
  relationships: Relationship[];
  selectedPersonId: string | null;
  onSelectPerson: (id: string) => void;
  onAddPerson: () => void;
  onDeleteRelationship: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  persons, 
  relationships,
  selectedPersonId, 
  onSelectPerson, 
  onAddPerson,
  onDeleteRelationship
}) => {
  const [activeTab, setActiveTab] = useState<'members' | 'relationships' | 'finder'>('members');
  const [search, setSearch] = useState('');
  const [searchCategory, setSearchCategory] = useState<'name' | 'profession' | 'location'>('name');
  const [isMembersOpen, setIsMembersOpen] = useState(true);

  const filteredPersons = persons.filter(p => {
    const s = search.toLowerCase();
    if (searchCategory === 'name') return p.full_name.toLowerCase().includes(s);
    if (searchCategory === 'profession') return p.profession?.toLowerCase().includes(s);
    if (searchCategory === 'location') return p.current_location?.toLowerCase().includes(s);
    return true;
  });

  return (
    <div className="w-64 border-r border-zinc-200 bg-white flex flex-col h-full overflow-hidden shrink-0">
      {/* Tabs */}
      <div className="flex border-b border-zinc-100">
        <button 
          onClick={() => setActiveTab('members')}
          className={cn(
            "flex-1 py-3 text-xs font-bold transition-colors border-b-2",
            activeTab === 'members' ? "border-brand text-brand" : "border-transparent text-zinc-400 hover:text-zinc-600"
          )}
        >
          Members
        </button>
        <button 
          onClick={() => setActiveTab('relationships')}
          className={cn(
            "flex-1 py-3 text-xs font-bold transition-colors border-b-2",
            activeTab === 'relationships' ? "border-brand text-brand" : "border-transparent text-zinc-400 hover:text-zinc-600"
          )}
        >
          Relationships
        </button>
        <button 
          onClick={() => setActiveTab('finder')}
          className={cn(
            "flex-1 py-3 text-xs font-bold transition-colors border-b-2",
            activeTab === 'finder' ? "border-brand text-brand" : "border-transparent text-zinc-400 hover:text-zinc-600"
          )}
        >
          Finder
        </button>
      </div>

      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {activeTab === 'members' ? (
          <>
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input 
                  type="text"
                  placeholder={`Search by ${searchCategory}...`}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand/10 transition-all"
                />
              </div>
              <div className="flex gap-1">
                {(['name', 'profession', 'location'] as const).map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSearchCategory(cat)}
                    className={cn(
                      "px-2 py-1 text-[10px] font-bold rounded uppercase tracking-wider border transition-all",
                      searchCategory === cat 
                        ? "bg-brand text-white border-brand" 
                        : "bg-white text-zinc-400 border-zinc-100 hover:border-zinc-200"
                    )}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <button 
                onClick={() => setIsMembersOpen(!isMembersOpen)}
                className="w-full flex items-center justify-between p-2 text-sm font-bold text-zinc-700 hover:bg-zinc-50 rounded-lg transition-colors"
              >
                <span>Family Members</span>
                <ChevronDown size={16} className={cn("transition-transform", !isMembersOpen && "-rotate-90")} />
              </button>

              {isMembersOpen && (
                <div className="space-y-0.5 mt-1">
                  {filteredPersons.length === 0 ? (
                    <div className="p-4 text-center text-zinc-400 text-xs italic">
                      No members found
                    </div>
                  ) : (
                    filteredPersons.map((person) => (
                      <button
                        key={person.id}
                        onClick={() => onSelectPerson(person.id)}
                        className={cn(
                          "w-full text-left px-3 py-2 rounded-lg transition-all flex items-center gap-3 text-sm group",
                          selectedPersonId === person.id
                            ? "bg-brand/5 text-brand font-semibold"
                            : "text-zinc-600 hover:bg-zinc-50"
                        )}
                      >
                        <div className="w-6 h-6 rounded-full bg-zinc-100 flex items-center justify-center shrink-0 overflow-hidden border border-zinc-200">
                          {person.photo_url ? (
                            <img src={person.photo_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <User size={12} className="text-zinc-400" />
                          )}
                        </div>
                        <span className="truncate flex-1">{person.full_name}</span>
                        {selectedPersonId === person.id && (
                          <div className="w-1.5 h-1.5 rounded-full bg-brand" />
                        )}
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </>
        ) : activeTab === 'relationships' ? (
          <div className="space-y-2">
            {relationships.length === 0 ? (
              <div className="p-8 text-center text-zinc-400 text-xs italic">
                No relationships defined
              </div>
            ) : (
              relationships.map((rel) => {
                const p1 = persons.find(p => p.id === rel.person1_id);
                const p2 = persons.find(p => p.id === rel.person2_id);
                if (!p1 || !p2) return null;

                return (
                  <div key={rel.id} className="bg-zinc-50 border border-zinc-100 p-3 rounded-xl group hover:border-zinc-200 transition-all">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                        {rel.type.replace('_', ' ')}
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteRelationship(rel.id);
                        }}
                        className="p-1 text-zinc-300 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] font-medium text-zinc-600">
                      <span className="truncate flex-1">{p1.full_name}</span>
                      <Users size={10} className="text-zinc-300 shrink-0" />
                      <span className="truncate flex-1 text-right">{p2.full_name}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          <RelationshipFinder persons={persons} relationships={relationships} />
        )}
      </div>

      <div className="p-4 border-t border-zinc-100">
        <button 
          onClick={onAddPerson}
          className="w-full flex items-center justify-center gap-2 py-2.5 bg-brand text-white rounded-lg text-sm font-bold hover:bg-brand-hover transition-all shadow-sm shadow-brand/20"
        >
          <Plus size={18} /> Add Person
        </button>
      </div>
    </div>
  );
};
