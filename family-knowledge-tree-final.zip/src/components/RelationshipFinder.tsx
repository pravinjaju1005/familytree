import React, { useState, useMemo } from 'react';
import { Person, Relationship } from '../types';
import { Search, Users, ArrowRight, Info, X } from 'lucide-react';
import { clsx } from 'clsx';

interface RelationshipFinderProps {
  persons: Person[];
  relationships: Relationship[];
}

export const RelationshipFinder: React.FC<RelationshipFinderProps> = ({ persons, relationships }) => {
  const [person1Id, setPerson1Id] = useState<string>('');
  const [person2Id, setPerson2Id] = useState<string>('');
  const [search1, setSearch1] = useState('');
  const [search2, setSearch2] = useState('');
  const [showResults, setShowResults] = useState(false);

  const filteredPersons1 = useMemo(() => 
    persons.filter(p => p.full_name.toLowerCase().includes(search1.toLowerCase())).slice(0, 5),
    [persons, search1]
  );

  const filteredPersons2 = useMemo(() => 
    persons.filter(p => p.full_name.toLowerCase().includes(search2.toLowerCase())).slice(0, 5),
    [persons, search2]
  );

  const findRelationship = () => {
    if (!person1Id || !person2Id) return "Please select two people.";
    if (person1Id === person2Id) return "Same person selected.";

    const p1 = persons.find(p => p.id === person1Id);
    const p2 = persons.find(p => p.id === person2Id);
    if (!p1 || !p2) return "Person not found.";

    // 1. Check for direct relationships
    const directRel = relationships.find(r => 
      ((r.person1_id === person1Id && r.person2_id === person2Id) || 
       (r.person2_id === person1Id && r.person1_id === person2Id))
    );
    
    if (directRel) {
      const isForward = directRel.person1_id === person1Id;
      if (directRel.type === 'SPOUSE_OF') return `${p1.full_name} is the spouse of ${p2.full_name}.`;
      if (directRel.type === 'PARENT_OF') return isForward ? `${p1.full_name} is the parent of ${p2.full_name}.` : `${p1.full_name} is the child of ${p2.full_name}.`;
      if (directRel.type === 'CHILD_OF') return isForward ? `${p1.full_name} is the child of ${p2.full_name}.` : `${p1.full_name} is the parent of ${p2.full_name}.`;
      if (directRel.type === 'SIBLING_OF') return `${p1.full_name} is the sibling of ${p2.full_name}.`;
      if (directRel.type === 'UNCLE_AUNT_OF') {
        const term = p1.gender === 'Female' ? 'Aunt' : p1.gender === 'Male' ? 'Uncle' : 'Aunt/Uncle';
        return isForward ? `${p1.full_name} is the ${term} of ${p2.full_name}.` : `${p1.full_name} is the niece/nephew of ${p2.full_name}.`;
      }
      if (directRel.type === 'IN_LAW_OF') {
        const term = p1.gender === 'Female' ? 'sister-in-law' : p1.gender === 'Male' ? 'brother-in-law' : 'in-law';
        return `${p1.full_name} is the ${term} of ${p2.full_name}.`;
      }
    }

    // 2. Get all ancestors for both people
    const getAncestors = (startId: string) => {
      const ancestors = new Map<string, number>();
      const queue: [string, number][] = [[startId, 0]];
      
      while (queue.length > 0) {
        const [id, dist] = queue.shift()!;
        if (!ancestors.has(id) || ancestors.get(id)! > dist) {
          ancestors.set(id, dist);
          
          // Find parents
          const parentRels = relationships.filter(r => 
            (r.type === 'PARENT_OF' && r.person2_id === id) ||
            (r.type === 'CHILD_OF' && r.person1_id === id)
          );
          
          parentRels.forEach(r => {
            const parentId = r.type === 'PARENT_OF' ? r.person1_id : r.person2_id;
            queue.push([parentId, dist + 1]);
          });
        }
      }
      return ancestors;
    };

    const ancestors1 = getAncestors(person1Id);
    const ancestors2 = getAncestors(person2Id);

    // 3. Find common ancestors and calculate distances
    let bestCommon: { id: string; d1: number; d2: number } | null = null;
    
    ancestors1.forEach((d1, id) => {
      if (ancestors2.has(id)) {
        const d2 = ancestors2.get(id)!;
        if (!bestCommon || (d1 + d2 < bestCommon.d1 + bestCommon.d2)) {
          bestCommon = { id, d1, d2 };
        }
      }
    });

    if (bestCommon) {
      const { d1, d2 } = bestCommon;
      
      // Direct Lineage
      if (d1 === 0 && d2 === 1) return `${p1.full_name} is the child of ${p2.full_name}.`;
      if (d1 === 1 && d2 === 0) return `${p1.full_name} is the parent of ${p2.full_name}.`;
      
      if (d1 === 0 && d2 === 2) return `${p1.full_name} is the grandchild of ${p2.full_name}.`;
      if (d1 === 2 && d2 === 0) return `${p1.full_name} is the grandparent of ${p2.full_name}.`;
      
      if (d1 === 0 && d2 > 2) {
        const greats = "great-".repeat(d2 - 2);
        return `${p1.full_name} is the ${greats}grandchild of ${p2.full_name}.`;
      }
      if (d1 > 2 && d2 === 0) {
        const greats = "great-".repeat(d1 - 2);
        return `${p1.full_name} is the ${greats}grandparent of ${p2.full_name}.`;
      }

      // Collateral
      if (d1 === 1 && d2 === 1) return `${p1.full_name} is the sibling of ${p2.full_name}.`;
      
      if (d1 === 1 && d2 === 2) {
        const term = p1.gender === 'Female' ? 'Aunt' : p1.gender === 'Male' ? 'Uncle' : 'Aunt/Uncle';
        return `${p1.full_name} is the ${term} of ${p2.full_name}.`;
      }
      if (d1 === 2 && d2 === 1) {
        const term = p1.gender === 'Female' ? 'Niece' : p1.gender === 'Male' ? 'Nephew' : 'Niece/Nephew';
        return `${p1.full_name} is the ${term} of ${p2.full_name}.`;
      }

      if (d1 === 1 && d2 > 2) {
        const greats = "great-".repeat(d2 - 2);
        const term = p1.gender === 'Female' ? 'Aunt' : p1.gender === 'Male' ? 'Uncle' : 'Aunt/Uncle';
        return `${p1.full_name} is the ${greats}${term} of ${p2.full_name}.`;
      }
      if (d1 > 2 && d2 === 1) {
        const greats = "great-".repeat(d1 - 2);
        const term = p1.gender === 'Female' ? 'Niece' : p1.gender === 'Male' ? 'Nephew' : 'Niece/Nephew';
        return `${p1.full_name} is the ${greats}${term} of ${p2.full_name}.`;
      }

      if (d1 === 2 && d2 === 2) return `${p1.full_name} is the 1st cousin of ${p2.full_name}.`;
      if (d1 === 3 && d2 === 3) return `${p1.full_name} is the 2nd cousin of ${p2.full_name}.`;
      if (d1 === 4 && d2 === 4) return `${p1.full_name} is the 3rd cousin of ${p2.full_name}.`;

      // Cousins removed
      if (d1 >= 2 && d2 >= 2) {
        const degree = Math.min(d1, d2) - 1;
        const removed = Math.abs(d1 - d2);
        const degreeStr = degree === 1 ? '1st' : degree === 2 ? '2nd' : degree === 3 ? '3rd' : `${degree}th`;
        const removedStr = removed === 1 ? 'once' : removed === 2 ? 'twice' : `${removed} times`;
        return `${p1.full_name} is the ${degreeStr} cousin ${removedStr} removed of ${p2.full_name}.`;
      }
    }

    // 4. Check for in-laws (spouse of a relative)
    // This is simplified: check if P1's spouse has a relationship to P2
    const p1SpouseRel = relationships.find(r => 
      r.type === 'SPOUSE_OF' && (r.person1_id === person1Id || r.person2_id === person1Id)
    );
    if (p1SpouseRel) {
      const spouseId = p1SpouseRel.person1_id === person1Id ? p1SpouseRel.person2_id : p1SpouseRel.person1_id;
      // Recursively check relationship for spouse (but avoid infinite loop)
      // For simplicity, just check direct ones
      const spouseAncestors = getAncestors(spouseId);
      const p2Ancestors = getAncestors(person2Id);
      
      let spouseCommon: { id: string; d1: number; d2: number } | null = null;
      spouseAncestors.forEach((d1, id) => {
        if (p2Ancestors.has(id)) {
          const d2 = p2Ancestors.get(id)!;
          if (!spouseCommon || (d1 + d2 < spouseCommon.d1 + spouseCommon.d2)) {
            spouseCommon = { id, d1, d2 };
          }
        }
      });

      if (spouseCommon) {
        const { d1, d2 } = spouseCommon;
        if (d1 === 1 && d2 === 0) return `${p1.full_name} is the step-parent of ${p2.full_name}.`;
        if (d1 === 1 && d2 === 1) return `${p1.full_name} is the in-law of ${p2.full_name}.`;
      }
    }

    return "No direct family connection found in the current tree.";
  };

  const result = useMemo(() => findRelationship(), [person1Id, person2Id, relationships]);

  return (
    <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200 space-y-4">
      <div className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">
        <Users size={14} /> Relationship Finder
      </div>

      <div className="grid grid-cols-1 gap-3">
        {/* Person 1 */}
        <div className="relative">
          <div className="flex items-center gap-2 px-3 py-2 bg-white border border-zinc-200 rounded-lg focus-within:border-brand transition-all">
            <Search size={14} className="text-zinc-400" />
            <input 
              type="text" 
              placeholder="First person..." 
              value={search1}
              onChange={(e) => {
                setSearch1(e.target.value);
                if (person1Id) setPerson1Id('');
              }}
              className="bg-transparent border-none outline-none text-sm w-full"
            />
            {person1Id && <X size={14} className="text-zinc-400 cursor-pointer" onClick={() => {setPerson1Id(''); setSearch1('');}} />}
          </div>
          {!person1Id && search1 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-zinc-200 rounded-lg shadow-xl z-50 overflow-hidden">
              {filteredPersons1.map(p => (
                <button 
                  key={p.id}
                  onClick={() => { setPerson1Id(p.id); setSearch1(p.full_name); }}
                  className="w-full text-left px-3 py-2 text-sm hover:bg-zinc-50 transition-colors border-b border-zinc-100 last:border-none"
                >
                  {p.full_name}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-center">
          <ArrowRight size={16} className="text-zinc-300 rotate-90" />
        </div>

        {/* Person 2 */}
        <div className="relative">
          <div className="flex items-center gap-2 px-3 py-2 bg-white border border-zinc-200 rounded-lg focus-within:border-brand transition-all">
            <Search size={14} className="text-zinc-400" />
            <input 
              type="text" 
              placeholder="Second person..." 
              value={search2}
              onChange={(e) => {
                setSearch2(e.target.value);
                if (person2Id) setPerson2Id('');
              }}
              className="bg-transparent border-none outline-none text-sm w-full"
            />
            {person2Id && <X size={14} className="text-zinc-400 cursor-pointer" onClick={() => {setPerson2Id(''); setSearch2('');}} />}
          </div>
          {!person2Id && search2 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-zinc-200 rounded-lg shadow-xl z-50 overflow-hidden">
              {filteredPersons2.map(p => (
                <button 
                  key={p.id}
                  onClick={() => { setPerson2Id(p.id); setSearch2(p.full_name); }}
                  className="w-full text-left px-3 py-2 text-sm hover:bg-zinc-50 transition-colors border-b border-zinc-100 last:border-none"
                >
                  {p.full_name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {(person1Id && person2Id) && (
        <div className="mt-4 p-3 bg-brand/5 border border-brand/10 rounded-lg flex gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
          <Info size={18} className="text-brand shrink-0 mt-0.5" />
          <div className="text-sm font-medium text-zinc-700 leading-relaxed">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};
