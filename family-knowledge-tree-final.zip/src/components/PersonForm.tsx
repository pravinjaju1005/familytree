import React, { useState, useEffect, useMemo } from 'react';
import { X, Save, Camera, Plus, Trash2 } from 'lucide-react';
import { Person, Gender } from '../types';

interface PersonFormProps {
  person?: Person | null;
  onSave: (person: Person) => void;
  onClose: () => void;
}

export const PersonForm: React.FC<PersonFormProps> = ({ person, onSave, onClose }) => {
  const [formData, setFormData] = useState<Person>({
    id: person?.id || crypto.randomUUID(),
    full_name: person?.full_name || '',
    nickname: person?.nickname || '',
    gender: person?.gender || 'Unknown',
    birth_date: person?.birth_date || '',
    birth_time: person?.birth_time || '',
    birth_place: person?.birth_place || '',
    current_location: person?.current_location || '',
    profession: person?.profession || '',
    current_company: person?.current_company || '',
    anniversary: person?.anniversary || '',
    education: person?.education || '',
    bio: person?.bio || '',
    photo_url: person?.photo_url || '',
    custom_fields: person?.custom_fields || '{}',
  });

  const customFields = useMemo(() => {
    try {
      return JSON.parse(formData.custom_fields || '{}') as Record<string, string>;
    } catch (e) {
      return {};
    }
  }, [formData.custom_fields]);

  const handleAddCustomField = () => {
    const newFields = { ...customFields, '': '' };
    setFormData({ ...formData, custom_fields: JSON.stringify(newFields) });
  };

  const handleUpdateCustomField = (oldKey: string, newKey: string, value: string) => {
    const newFields = { ...customFields };
    if (oldKey !== newKey) {
      delete newFields[oldKey];
    }
    newFields[newKey] = value;
    setFormData({ ...formData, custom_fields: JSON.stringify(newFields) });
  };

  const handleRemoveCustomField = (key: string) => {
    const newFields = { ...customFields };
    delete newFields[key];
    setFormData({ ...formData, custom_fields: JSON.stringify(newFields) });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
          <h2 className="text-xl font-bold text-zinc-900">
            {person ? 'Edit Family Member' : 'Add New Member'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[70vh] space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.full_name}
                  onChange={e => setFormData({...formData, full_name: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Nickname</label>
                <input 
                  type="text" 
                  value={formData.nickname}
                  onChange={e => setFormData({...formData, nickname: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                  placeholder="e.g. 'Junior'"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Gender</label>
                <select 
                  value={formData.gender}
                  onChange={e => setFormData({...formData, gender: e.target.value as Gender})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                  <option value="Unknown">Unknown</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Birth Date</label>
                  <input 
                    type="date" 
                    value={formData.birth_date}
                    onChange={e => setFormData({...formData, birth_date: e.target.value})}
                    className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Birth Time</label>
                  <input 
                    type="time" 
                    value={formData.birth_time}
                    onChange={e => setFormData({...formData, birth_time: e.target.value})}
                    className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Birth Place</label>
                <input 
                  type="text" 
                  value={formData.birth_place}
                  onChange={e => setFormData({...formData, birth_place: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                  placeholder="City, Country"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Current Location</label>
                <input 
                  type="text" 
                  value={formData.current_location}
                  onChange={e => setFormData({...formData, current_location: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Profession</label>
                <input 
                  type="text" 
                  value={formData.profession}
                  onChange={e => setFormData({...formData, profession: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Current Company</label>
                <input 
                  type="text" 
                  value={formData.current_company}
                  onChange={e => setFormData({...formData, current_company: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Anniversary</label>
                <input 
                  type="date" 
                  value={formData.anniversary}
                  onChange={e => setFormData({...formData, anniversary: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Education</label>
                <input 
                  type="text" 
                  value={formData.education}
                  onChange={e => setFormData({...formData, education: e.target.value})}
                  className="w-full p-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Photo URL</label>
                <div className="relative">
                  <Camera className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                  <input 
                    type="url" 
                    value={formData.photo_url}
                    onChange={e => setFormData({...formData, photo_url: e.target.value})}
                    placeholder="https://..."
                    className="w-full pl-10 pr-4 py-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Biography / Notes</label>
            <textarea 
              rows={4}
              value={formData.bio}
              onChange={e => setFormData({...formData, bio: e.target.value})}
              className="w-full p-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none resize-none"
              placeholder="Tell us about this person..."
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-zinc-500 uppercase">Additional Details</label>
              <button 
                type="button"
                onClick={handleAddCustomField}
                className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 hover:text-zinc-900 uppercase tracking-wider transition-colors"
              >
                <Plus size={12} /> Add Field
              </button>
            </div>
            
            <div className="space-y-3">
              {Object.entries(customFields).map(([key, value], index) => (
                <div key={index} className="flex gap-3 items-start animate-in slide-in-from-left-2 duration-200">
                  <div className="flex-1">
                    <input 
                      type="text"
                      placeholder="Field Name (e.g. Company)"
                      value={key}
                      onChange={e => handleUpdateCustomField(key, e.target.value, value as string)}
                      className="w-full p-2 text-xs border border-zinc-200 rounded-lg focus:ring-2 focus:ring-zinc-900/10 outline-none font-bold"
                    />
                  </div>
                  <div className="flex-[2]">
                    <input 
                      type="text"
                      placeholder="Value"
                      value={value as string}
                      onChange={e => handleUpdateCustomField(key, key, e.target.value)}
                      className="w-full p-2 text-xs border border-zinc-200 rounded-lg focus:ring-2 focus:ring-zinc-900/10 outline-none"
                    />
                  </div>
                  <button 
                    type="button"
                    onClick={() => handleRemoveCustomField(key)}
                    className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {Object.keys(customFields).length === 0 && (
                <p className="text-[10px] text-zinc-400 italic">No additional details added yet.</p>
              )}
            </div>
          </div>
        </form>

        <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-sm font-bold text-zinc-600 hover:bg-zinc-200 rounded-xl transition-all"
          >
            Cancel
          </button>
          <button 
            onClick={handleSubmit}
            className="px-6 py-2.5 bg-zinc-900 text-white text-sm font-bold rounded-xl hover:bg-zinc-800 shadow-lg shadow-zinc-900/20 transition-all flex items-center gap-2"
          >
            <Save size={18} /> Save Member
          </button>
        </div>
      </div>
    </div>
  );
};
