import React, { useState } from 'react';
import { X, Save, ArrowRightLeft } from 'lucide-react';
import { Person, Relationship, RelationshipType } from '../types';

interface RelationshipFormProps {
  persons: Person[];
  onSave: (rel: Relationship) => void;
  onClose: () => void;
}

export const RelationshipForm: React.FC<RelationshipFormProps> = ({ persons, onSave, onClose }) => {
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<Relationship>({
    id: crypto.randomUUID(),
    person1_id: persons[0]?.id || '',
    person2_id: persons[1]?.id || '',
    type: 'PARENT_OF',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.person1_id === formData.person2_id) {
      setError("A person cannot have a relationship with themselves.");
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
          <h2 className="text-xl font-bold text-zinc-900">Add Relationship</h2>
          <button onClick={onClose} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {error && (
            <div className="p-3 bg-red-50 border border-red-100 text-red-600 text-xs font-bold rounded-lg animate-in slide-in-from-top-2 duration-200">
              {error}
            </div>
          )}
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 space-y-2">
              <label className="block text-xs font-bold text-zinc-500 uppercase">Person 1</label>
              <select 
                value={formData.person1_id}
                onChange={e => setFormData({...formData, person1_id: e.target.value})}
                className="w-full p-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none bg-white"
              >
                {persons.map(p => (
                  <option key={p.id} value={p.id}>{p.full_name}</option>
                ))}
              </select>
            </div>

            <div className="mt-6 p-2 bg-zinc-100 rounded-full text-zinc-400">
              <ArrowRightLeft size={20} />
            </div>

            <div className="flex-1 space-y-2">
              <label className="block text-xs font-bold text-zinc-500 uppercase">Person 2</label>
              <select 
                value={formData.person2_id}
                onChange={e => setFormData({...formData, person2_id: e.target.value})}
                className="w-full p-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 outline-none bg-white"
              >
                {persons.map(p => (
                  <option key={p.id} value={p.id}>{p.full_name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-zinc-500 uppercase">Relationship Type</label>
            <div className="grid grid-cols-2 gap-3">
              {(['PARENT_OF', 'SPOUSE_OF', 'SIBLING_OF', 'OTHER'] as RelationshipType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({...formData, type})}
                  className={`p-4 rounded-xl border-2 transition-all text-sm font-bold text-left ${
                    formData.type === type 
                      ? 'border-zinc-900 bg-zinc-900 text-white shadow-lg shadow-zinc-900/20' 
                      : 'border-zinc-100 bg-zinc-50 text-zinc-600 hover:border-zinc-200'
                  }`}
                >
                  {type.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <p className="text-xs text-zinc-400 italic text-center">
            Note: Relationships are bidirectional. Adding "Parent of" will automatically imply "Child of" in the graph.
          </p>
        </form>

        <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-sm font-bold text-zinc-600 hover:bg-zinc-200 rounded-xl transition-all"
          >
            Cancel
          </button>
          <button 
            onClick={handleSubmit}
            className="px-6 py-2.5 bg-zinc-900 text-white text-sm font-bold rounded-xl hover:bg-zinc-800 shadow-lg shadow-zinc-900/20 transition-all flex items-center gap-2"
          >
            <Save size={18} /> Create Relationship
          </button>
        </div>
      </div>
    </div>
  );
};
