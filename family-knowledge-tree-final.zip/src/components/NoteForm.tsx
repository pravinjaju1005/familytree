import React, { useState } from 'react';
import { X, Save, MessageSquare, Calendar, Clock } from 'lucide-react';
import { Note } from '../types';

interface NoteFormProps {
  personId: string;
  onSave: (note: Partial<Note>) => void;
  onClose: () => void;
}

export const NoteForm: React.FC<NoteFormProps> = ({ personId, onSave, onClose }) => {
  const [topic, setTopic] = useState('');
  const [content, setContent] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [followUpTopic, setFollowUpTopic] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      person_id: personId,
      topic,
      content,
      date: new Date().toISOString(),
      follow_up_date: followUpDate || undefined,
      follow_up_topic: followUpTopic || undefined,
      is_completed: false
    });
  };

  return (
    <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="px-6 py-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand/10 rounded-lg flex items-center justify-center text-brand">
              <MessageSquare size={18} />
            </div>
            <h2 className="text-lg font-bold text-zinc-900">Add Conversation Note</h2>
          </div>
          <button onClick={onClose} className="p-2 text-zinc-400 hover:text-zinc-600 rounded-lg transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider ml-1">Topic</label>
            <input
              required
              type="text"
              placeholder="e.g. Family Reunion, Health Update"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand/10 transition-all"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider ml-1">Notes</label>
            <textarea
              required
              rows={4}
              placeholder="What did you discuss?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand/10 transition-all resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider ml-1 flex items-center gap-1">
                <Calendar size={10} /> Follow-up Date
              </label>
              <input
                type="date"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand/10 transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider ml-1 flex items-center gap-1">
                <Clock size={10} /> Follow-up Topic
              </label>
              <input
                type="text"
                placeholder="e.g. Check RSVP"
                value={followUpTopic}
                onChange={(e) => setFollowUpTopic(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand/10 transition-all"
              />
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 border border-zinc-200 text-zinc-600 rounded-xl text-sm font-bold hover:bg-zinc-50 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2.5 bg-brand text-white rounded-xl text-sm font-bold hover:bg-brand-hover transition-all shadow-lg shadow-brand/20 flex items-center justify-center gap-2"
            >
              <Save size={18} /> Save Note
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
