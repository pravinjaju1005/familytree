import React, { useState, useEffect, useCallback } from 'react';
import { 
  X, MapPin, Briefcase, GraduationCap, Calendar, 
  Plus, Trash2, MessageSquare, Clock, UserCheck, 
  Edit3, Camera, Users, MoreHorizontal, ChevronDown, Circle
} from 'lucide-react';
import { Person, Note, Relationship } from '../types';
import { api } from '../services/api';
import { format, differenceInYears, parseISO } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { Tag } from 'lucide-react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ProfilePanelProps {
  person: Person | null;
  allPersons: Person[];
  allRelationships: Relationship[];
  onClose: () => void;
  onEdit: (person: Person) => void;
  onDelete: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onRefresh: () => void;
  onAddNote: () => void;
}

export const ProfilePanel: React.FC<ProfilePanelProps> = ({ 
  person, 
  onClose, 
  onEdit, 
  onDelete,
  onDeleteNote,
  onAddNote
}) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isBioOpen, setIsBioOpen] = useState(true);
  const [isLogOpen, setIsLogOpen] = useState(true);

  const fetchNotes = useCallback(() => {
    if (person) {
      api.getNotes(person.id).then(setNotes);
    }
  }, [person]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  if (!person) return null;

  const handleDeleteNote = async (id: string) => {
    await onDeleteNote(id);
    fetchNotes();
  };

  const calculateAge = (birthDate?: string) => {
    if (!birthDate) return 'Unknown';
    try {
      return differenceInYears(new Date(), parseISO(birthDate));
    } catch (e) {
      return 'Unknown';
    }
  };

  const customFields = (() => {
    try {
      return JSON.parse(person.custom_fields || '{}') as Record<string, string>;
    } catch (e) {
      return {};
    }
  })();

  return (
    <div className="w-[400px] border-l border-zinc-200 bg-white flex flex-col h-full overflow-hidden shrink-0">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b border-zinc-100">
        <h2 className="text-xl font-bold text-zinc-900">{person.full_name}</h2>
        <div className="flex items-center gap-1">
          <button 
            onClick={() => onEdit(person)}
            className="p-2 text-zinc-400 hover:text-brand hover:bg-brand/5 rounded-lg transition-all"
            title="Edit Profile"
          >
            <Edit3 size={18} />
          </button>
          <button 
            onClick={() => onDelete(person.id)}
            className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
            title="Delete Profile"
          >
            <Trash2 size={18} />
          </button>
          <button className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors">
            <MoreHorizontal size={20} />
          </button>
          <button onClick={onClose} className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors">
            <X size={20} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Profile Section */}
        <div className="p-6 flex gap-6 border-b border-zinc-100 bg-zinc-50/30">
          <div className="w-32 h-40 rounded-xl overflow-hidden shrink-0 shadow-sm border-2 border-white">
            {person.photo_url ? (
              <img src={person.photo_url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-full h-full bg-zinc-100 flex items-center justify-center text-zinc-400 text-4xl font-bold">
                {person.full_name.charAt(0)}
              </div>
            )}
          </div>
          <div className="space-y-3 min-w-0 flex-1">
            <div className="text-lg font-bold text-zinc-900">Age: {calculateAge(person.birth_date)}</div>
            <div className="space-y-2">
              <InfoItem 
                icon={
                  <Circle 
                    size={12} 
                    className={clsx(
                      "fill-current",
                      person.gender?.toLowerCase() === 'male' ? "text-blue-500" : 
                      person.gender?.toLowerCase() === 'female' ? "text-pink-500" : 
                      "text-zinc-400"
                    )} 
                  />
                } 
                label="Gender" 
                value={person.gender} 
              />
              <InfoItem icon={<MapPin size={14} className="text-zinc-400" />} label="Born" value={`${format(parseISO(person.birth_date || '1970-01-01'), 'MMM d, yyyy')}, ${person.birth_place}`} />
              <InfoItem icon={<MapPin size={14} className="text-zinc-400" />} label="Location" value={person.current_location} />
              <InfoItem icon={<Briefcase size={14} className="text-zinc-400" />} label="Profession" value={person.profession} />
              <InfoItem icon={<Briefcase size={14} className="text-zinc-400" />} label="Company" value={person.current_company} />
              <InfoItem icon={<Calendar size={14} className="text-zinc-400" />} label="Anniversary" value={person.anniversary ? format(parseISO(person.anniversary), 'MMM d, yyyy') : undefined} />
              <InfoItem icon={<GraduationCap size={14} className="text-zinc-400" />} label="Education" value={person.education} />
              
              {Object.entries(customFields).map(([key, value], idx) => (
                key && value && (
                  <InfoItem 
                    key={idx} 
                    icon={<Tag size={14} className="text-zinc-400" />} 
                    label={key} 
                    value={value} 
                  />
                )
              ))}
            </div>
          </div>
        </div>

        {/* Bio Section */}
        <div className="border-b border-zinc-100">
          <button 
            onClick={() => setIsBioOpen(!isBioOpen)}
            className="w-full px-6 py-4 flex items-center justify-between text-sm font-bold text-zinc-900 hover:bg-zinc-50 transition-colors"
          >
            <span>Bio</span>
            <ChevronDown size={18} className={cn("transition-transform", !isBioOpen && "-rotate-90")} />
          </button>
          {isBioOpen && (
            <div className="px-6 pb-6 text-sm text-zinc-600 leading-relaxed italic">
              {person.bio || "No biography available."}
            </div>
          )}
        </div>

        {/* Conversation Log Section */}
        <div>
          <div className="flex items-center justify-between px-6 py-4">
            <button 
              onClick={() => setIsLogOpen(!isLogOpen)}
              className="flex items-center gap-2 text-sm font-bold text-zinc-900 hover:text-brand transition-colors"
            >
              <span>Conversation Log</span>
              <ChevronDown size={18} className={cn("transition-transform", !isLogOpen && "-rotate-90")} />
            </button>
            <button 
              onClick={onAddNote}
              className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-brand hover:bg-brand/5 rounded transition-all uppercase tracking-wider"
            >
              <Plus size={12} /> Add Note
            </button>
          </div>
          {isLogOpen && (
            <div className="px-6 pb-6 space-y-6">
              {notes.length === 0 ? (
                <div className="text-center py-4 text-zinc-400 text-xs italic">
                  No conversation logs found.
                </div>
              ) : (
                notes.map(note => (
                  <div key={note.id} className="space-y-2 group/note relative">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-bold text-brand">{format(parseISO(note.date), 'MM/dd/yyyy')}</span>
                        <span className="text-zinc-500">Discussed: <span className="font-bold text-zinc-900">"{note.topic}"</span></span>
                      </div>
                      <button 
                        onClick={() => handleDeleteNote(note.id)}
                        className="p-1 text-zinc-300 hover:text-red-500 opacity-0 group-hover/note:opacity-100 transition-all"
                        title="Delete Note"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                    <div className="ml-4 space-y-2">
                      <div className="text-xs text-zinc-600 italic">Notes: {note.content}</div>
                      {note.follow_up_reminder && (
                        <div className="flex items-center gap-2 text-xs text-zinc-700 bg-zinc-50 p-2 rounded border border-zinc-100">
                          <input type="checkbox" checked readOnly className="rounded border-zinc-300 text-brand focus:ring-brand" />
                          <span>Reminder: Follow up on {note.follow_up_reminder}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const InfoItem: React.FC<{ icon: React.ReactNode, label: string, value?: string }> = ({ icon, label, value }) => (
  <div className="flex items-center gap-2 text-xs">
    <span className="shrink-0">{icon}</span>
    <span className="text-zinc-500">{label}: <span className="text-zinc-900 font-medium">{value || 'Not specified'}</span></span>
  </div>
);
