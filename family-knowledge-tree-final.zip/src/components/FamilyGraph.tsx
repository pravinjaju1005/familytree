import React, { useMemo, useCallback, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  MarkerType,
  Node,
  Panel,
  useReactFlow,
  ReactFlowProvider,
  Handle,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from 'dagre';
import { Person, Relationship, Note } from '../types';
import { Plus, ZoomIn, ZoomOut, Maximize2, User, X, Filter, ChevronLeft, ChevronRight, MoreHorizontal, GitGraph as Tree } from 'lucide-react';
import { clsx } from 'clsx';
import { format } from 'date-fns';

const nodeWidth = 180;
const nodeHeight = 60;

const getLayoutedElements = (nodes: Node[], edges: Edge[], direction = 'TB') => {
  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));
  dagreGraph.setGraph({ rankdir: direction, nodesep: 200, ranksep: 150 });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    const type = (edge.data as any)?.type;
    if (type === 'CHILD_OF') {
      // Child -> Parent edge should be Parent -> Child for layout
      dagreGraph.setEdge(edge.target, edge.source);
    } else if (type === 'SPOUSE_OF') {
      // Spouses should ideally be on the same rank.
      // We don't add spouse edges to dagre to avoid forcing a vertical hierarchy between them.
      // They will be positioned based on their other relationships (like children).
    } else {
      dagreGraph.setEdge(edge.source, edge.target);
    }
  });

  dagre.layout(dagreGraph);

  const layoutedNodes = nodes.map((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    return {
      ...node,
      position: {
        x: nodeWithPosition.x - nodeWidth / 2,
        y: nodeWithPosition.y - nodeHeight / 2,
      },
    };
  });

  return { nodes: layoutedNodes, edges };
};

interface FamilyGraphProps {
  persons: Person[];
  relationships: Relationship[];
  allNotes: Note[];
  selectedPersonId: string | null;
  onSelectPerson: (id: string) => void;
  onAddRelationship: () => void;
}

const PersonNode = ({ data, selected }: { data: { person: Person; onSelect: (id: string) => void }; selected: boolean }) => {
  const genderColor = useMemo(() => {
    switch (data.person.gender?.toLowerCase()) {
      case 'male': return 'border-blue-200 bg-blue-50 text-blue-900';
      case 'female': return 'border-pink-200 bg-pink-50 text-pink-900';
      default: return 'border-zinc-200 bg-zinc-50 text-zinc-900';
    }
  }, [data.person.gender]);

  const selectedColor = useMemo(() => {
    switch (data.person.gender?.toLowerCase()) {
      case 'male': return 'bg-blue-600 border-blue-600 shadow-blue-600/20';
      case 'female': return 'bg-pink-600 border-pink-600 shadow-pink-600/20';
      default: return 'bg-zinc-900 border-zinc-900 shadow-zinc-900/20';
    }
  }, [data.person.gender]);

  return (
    <div 
      onClick={() => data.onSelect(data.person.id)}
      className={clsx(
        "flex items-center gap-2 px-3 py-2 rounded-xl border transition-all cursor-pointer w-[180px] h-[60px] relative",
        selected 
          ? `${selectedColor} shadow-lg text-white` 
          : `${genderColor} hover:border-zinc-300`
      )}
    >
      <Handle type="target" position={Position.Top} className="w-2 h-2 !bg-zinc-400 border-none" />
      
      <div className={clsx(
        "w-8 h-8 rounded-full flex-shrink-0 overflow-hidden border flex items-center justify-center",
        selected ? "bg-white/20 border-white/30" : "bg-white border-zinc-200"
      )}>
        {data.person.photo_url ? (
          <img src={data.person.photo_url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        ) : (
          <User size={16} className={selected ? "text-white" : "text-zinc-400"} />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className={clsx("text-sm font-bold truncate", selected ? "text-white" : "")}>
          {data.person.full_name}
        </div>
        <div className={clsx("text-[10px] uppercase tracking-wider font-bold opacity-70", selected ? "text-white/80" : "text-zinc-500")}>
          {data.person.profession || 'Member'}
        </div>
      </div>

      <Handle type="source" position={Position.Bottom} className="w-2 h-2 !bg-zinc-400 border-none" />
    </div>
  );
};

const nodeTypes = {
  person: PersonNode,
};

const FamilyGraphContent: React.FC<FamilyGraphProps> = ({ 
  persons, 
  relationships, 
  allNotes,
  selectedPersonId,
  onSelectPerson,
  onAddRelationship
}) => {
  const { fitView, zoomIn, zoomOut } = useReactFlow();

  const initialNodes: Node[] = useMemo(() => 
    persons.map(p => ({
      id: p.id,
      type: 'person',
      data: { person: p, onSelect: onSelectPerson },
      position: { x: 0, y: 0 },
      selected: p.id === selectedPersonId
    })), [persons, onSelectPerson, selectedPersonId]);

  const initialEdges: Edge[] = useMemo(() => {
    return relationships
      .filter(r => r.type !== 'UNCLE_AUNT_OF' && r.type !== 'IN_LAW_OF')
      .map(r => ({
        id: r.id,
        source: r.person1_id,
        target: r.person2_id,
      data: { type: r.type },
      label: (r.type || 'relationship').replace('_', ' ').toLowerCase(),
      type: 'smoothstep',
      pathOptions: { borderRadius: 20 },
      markerEnd: r.type === 'SPOUSE_OF' ? undefined : { 
        type: MarkerType.ArrowClosed, 
        color: '#a1a1aa',
        width: 15,
        height: 15
      },
      style: { 
        stroke: '#a1a1aa', 
        strokeWidth: 2,
        strokeDasharray: r.type === 'SPOUSE_OF' ? '5,5' : undefined
      },
    }));
  }, [relationships]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  useEffect(() => {
    if (initialNodes.length > 0) {
      const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
        initialNodes,
        initialEdges
      );
      setNodes([...layoutedNodes]);
      setEdges([...layoutedEdges]);
      setTimeout(() => fitView({ duration: 800, padding: 0.2 }), 100);
    }
  }, [initialNodes, initialEdges, setNodes, setEdges, fitView]);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const notesByMonth = useMemo(() => {
    const groups: { [key: string]: Note[] } = {};
    allNotes.forEach(note => {
      try {
        const date = new Date(note.date);
        const monthYear = format(date, 'MMMM yyyy');
        if (!groups[monthYear]) groups[monthYear] = [];
        groups[monthYear].push(note);
      } catch (e) {
        console.error("Invalid date in note:", note);
      }
    });
    return groups;
  }, [allNotes]);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50/50">
      {/* Graph Area */}
      <div className="flex-1 min-h-0 relative bg-white border-b border-zinc-100">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
          minZoom={0.1}
          maxZoom={2}
        >
          <Background color="#f4f4f5" gap={20} />
          
          <Panel position="top-left" className="m-4 flex flex-col gap-2">
            <button
              onClick={onAddRelationship}
              className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-lg shadow-lg shadow-zinc-900/20 hover:bg-zinc-800 transition-all text-sm font-bold"
            >
              <Plus size={18} /> Add Relationship
            </button>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white border border-zinc-200 rounded-lg shadow-sm text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
              <Tree size={12} className="text-brand" /> Tree View Active
            </div>
          </Panel>

          <Panel position="top-right" className="m-4 flex items-center bg-white border border-zinc-200 rounded-lg shadow-sm overflow-hidden">
            <button
              onClick={() => zoomIn()}
              className="p-2 hover:bg-zinc-50 transition-colors text-zinc-600 border-r border-zinc-200 flex items-center gap-2 text-xs font-medium"
            >
              <ZoomIn size={16} /> Zoom In
            </button>
            <button
              onClick={() => zoomOut()}
              className="p-2 hover:bg-zinc-50 transition-colors text-zinc-600 border-r border-zinc-200 flex items-center gap-2 text-xs font-medium"
            >
              <ZoomOut size={16} /> Zoom Out
            </button>
            <button
              onClick={() => fitView({ duration: 400 })}
              className="p-2 hover:bg-zinc-50 transition-colors text-zinc-600 flex items-center gap-2 text-xs font-medium"
            >
              <Maximize2 size={16} /> Fit View
            </button>
          </Panel>
        </ReactFlow>
      </div>

      {/* Filter Bar */}
      <div className="px-6 py-3 bg-white border-b border-zinc-100 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button className="text-[11px] font-bold text-zinc-400 hover:text-zinc-600 uppercase tracking-wider">
            Clear Search
          </button>
          <div className="flex items-center gap-2 bg-zinc-50 border border-zinc-100 rounded-lg px-3 py-1.5">
            <Filter size={12} className="text-zinc-400" />
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Filters:</span>
            <div className="flex items-center gap-1">
              <span className="text-xs font-bold text-zinc-900">All Members</span>
            </div>
          </div>
        </div>
      </div>

      {/* Timeline Section */}
      <div className="flex-1 overflow-y-auto bg-zinc-50/50 p-6 space-y-8">
        {Object.keys(notesByMonth).length === 0 ? (
          <div className="text-center py-12 text-zinc-400 italic text-sm">
            No conversation logs yet. Add notes to family members to see them here.
          </div>
        ) : (
          Object.entries(notesByMonth).map(([month, notes]) => (
            <div key={month} className="space-y-4">
              <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
                {month.split(' ')[0]} <span className="text-zinc-400 font-medium">{month.split(' ')[1]}</span>
              </h3>
              <div className="space-y-3">
                {(notes as Note[]).map(note => {
                  const person = persons.find(p => p.id === note.person_id);
                  return (
                    <ActivityItem 
                      key={note.id}
                      day={format(new Date(note.date), 'EEE, MMM d')} 
                      content={
                        <span>
                          Discussed <span className="font-bold text-zinc-900">"{note.topic}"</span> with <span className="font-bold text-zinc-900">{person?.full_name || 'Unknown'}</span>
                        </span>
                      }
                      photoUrl={person?.photo_url}
                    />
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const ActivityItem: React.FC<{ day: string, content: React.ReactNode, photoUrl?: string }> = ({ day, content, photoUrl }) => (
  <div className="bg-white border border-zinc-100 rounded-xl p-4 flex items-center gap-4 shadow-sm hover:border-zinc-200 transition-all group">
    <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider w-24 shrink-0">{day}</div>
    <div className="text-sm text-zinc-600 flex-1">{content}</div>
    <div className="w-6 h-6 rounded-full bg-zinc-100 flex items-center justify-center shrink-0 group-hover:bg-zinc-200 transition-colors overflow-hidden border border-zinc-200">
      {photoUrl ? (
        <img src={photoUrl} alt="" className="w-full h-full object-cover" />
      ) : (
        <User size={12} className="text-zinc-400" />
      )}
    </div>
  </div>
);

export const FamilyGraph: React.FC<FamilyGraphProps> = (props) => (
  <ReactFlowProvider>
    <FamilyGraphContent {...props} />
  </ReactFlowProvider>
);
